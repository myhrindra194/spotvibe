# Agora-RTE-Extension Demo

A simple demo for how to create video and audio extension for Agora Web SDK NG.

Detailed documentation [here](https://docs.agora.io/en/extension_vendor/plugin_web_ng?platform=Web).

## Install Dependencies

```shell
npm install
```

## Build

```shell
npm run build
```

## Run the demo

```shell
npm run demo
```
